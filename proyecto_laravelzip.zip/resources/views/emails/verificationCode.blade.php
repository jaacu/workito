<html>
<head>
	<meta charset="UTF-8">
	<title>Email</title>
</head>
<body>
	<p>Nos alegra tenerte a bordo {{ $name }}</p>
	<p>Este mail fue generado con laravelsito jeje</p>
	<p>Su firma digital es: </p>
	<span style="border: solid black; color: blue; "> {{ $code }} </span>
	<p>Te sugerimos guardarla en un lugar seguro ya que sera tu forma de validar tus operaciones con nosotros. </p>
</body>
</html>