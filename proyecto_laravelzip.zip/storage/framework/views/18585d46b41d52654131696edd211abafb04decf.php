<?php if($user->isDeveloper() ): ?>
<p>Este desarrollador esta trabajando en: <?php echo e($user->devs->count()); ?></p>
<p>Comentarios realizados: <?php echo e($user->comments->count()); ?></p>
<?php endif; ?>

<?php if($user->isClient()): ?>
<p>Este usuario ha creado <?php echo e($user->getProyects()->count()); ?> proyectos.</p>
<p>Este usuario esta relacionado con <?php echo e(count( $user->proyectsClient() )); ?> proyectos en desarrollo.</p>
<?php endif; ?>