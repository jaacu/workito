<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-2">
		<div class="col-sm-12">
			<?php if (! ( isset($type) )): ?>
			<?php echo $__env->make('proyecto.proyecto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endif; ?>

			<?php if(isset( $type )): ?>
			<?php echo $__env->make($view, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php if( Auth::user()->isAdmin() ): ?>
			<div class="row my-5">
				<div class="col-sm-6 text-center">
					<h3><a class="btn btn-outline-primary btn-lg w-20" href=" <?php echo e(route('user', $proyecto->user->id )); ?>"><?php echo e($proyecto->user->name); ?> </a></h3>
				</div>
				<?php if( $proyecto->encontrar() ): ?>
				<div class="col-sm-6 text-center">
					<a href="<?php echo e(route('proyecto.show', $proyecto->encontrar()->id )); ?>" class="btn btn-primary btn-lg">Ver proyecto en desarrollo.</a>
					<?php else: ?>
					<a href="<?php echo e(route('proyecto.asignar', [ $proyecto->getType() , $proyecto->id] )); ?>" class="btn btn-secondary btn-lg">Asignar proyecto.</a>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>