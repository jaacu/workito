<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-12-my-2">
			<h1>Editar el Dossier: <?php echo e($proyecto->nombre); ?></h1>	
		</div>
		<div class="col-sm-12 my-2">
			<form action="<?php echo e(route('proyecto.dossier.edit',$proyecto->id)); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="form-row">
					<div class="col-sm-8 text-center mx-auto"> 
						<label for="nombre" class="">Nombre de la empresa:</label>
						<input id="nombre" type="text" class=" text-center form-control <?php if( $errors->has('nombre')): ?> is-invalid <?php endif; ?>" name="nombre" value="<?php echo e($proyecto->nombre); ?>" required autofocus>
						<?php $__currentLoopData = $errors->get('nombre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($error); ?></strong>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>

				<div class="form-row my-3">
					<div class="col-sm-6 text-center"> 
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="queEs" class="">Descripcion de la empresa:</label>
							<input id="queEs" type="text" class=" text-center form-control <?php if( $errors->has('queEs')): ?> is-invalid <?php endif; ?>" name="queEs" value="<?php echo e($proyecto->queEs); ?>" required>
							<?php $__currentLoopData = $errors->get('queEs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="publico" class="">Hacia que publico va dirigido?</label>
							<input id="publico" type="text" class=" text-center form-control <?php if( $errors->has('publico')): ?> is-invalid <?php endif; ?>" name="publico" value="<?php echo e($proyecto->publico); ?>" required>
							<?php $__currentLoopData = $errors->get('publico'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				
				<div class="form-row my-3">
					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="mision" class="">Mision de la empresa:</label>
							<input id="mision" type="text" class=" text-center form-control <?php if( $errors->has('mision')): ?> is-invalid <?php endif; ?>" name="mision" value="<?php echo e($proyecto->mision); ?>" required>
							<?php $__currentLoopData = $errors->get('mision'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="vision" class="">Vision de la empresa:</label>
							<input id="vision" type="text" class=" text-center form-control <?php if( $errors->has('vision')): ?> is-invalid <?php endif; ?>" name="vision" value="<?php echo e($proyecto->vision); ?>" required>
							<?php $__currentLoopData = $errors->get('vision'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>

				<div class="form-row my-3">
					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="valores" class="">Valores de la empresa:</label>
							<input id="valores" type="text" class=" text-center form-control <?php if( $errors->has('valores')): ?> is-invalid <?php endif; ?>" name="valores" value="<?php echo e($proyecto->valores); ?>" required>
							<?php $__currentLoopData = $errors->get('valores'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="servicios" class="">Que servicios ofrece la empresa?</label>
							<input id="servicios" type="text" class=" text-center form-control <?php if( $errors->has('servicios')): ?> is-invalid <?php endif; ?>" name="servicios" value="<?php echo e($proyecto->servicios); ?>" required>
							<?php $__currentLoopData = $errors->get('servicios'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				
				<div class="form-row my-3">
					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="crecimiento" class="">Cuales son las proyecciones de crecimiento de la empresa? </label>
							<input id="crecimiento" type="text" class=" text-center form-control <?php if( $errors->has('crecimiento')): ?> is-invalid <?php endif; ?>" name="crecimiento" value="<?php echo e($proyecto->crecimiento); ?>" required>
							<?php $__currentLoopData = $errors->get('crecimiento'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="que_se_puede_encontrar" class="">Que se puede encontrar en la empresa?</label>
							<input id="que_se_puede_encontrar" type="text" class=" text-center form-control <?php if( $errors->has('que_se_puede_encontrar')): ?> is-invalid <?php endif; ?>" name="que_se_puede_encontrar" value="<?php echo e($proyecto->que_se_puede_encontrar); ?>" required>
							<?php $__currentLoopData = $errors->get('que_se_puede_encontrar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				
				<div class="form-row my-3">
					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="cualidades" class="">Describe en 4 palabras las cualidades de la empresa: </label>
							<input id="cualidades" type="text" class=" text-center form-control <?php if( $errors->has('cualidades')): ?> is-invalid <?php endif; ?>" name="cualidades" value="<?php echo e($proyecto->cualidades); ?>" required placeholder="calidad, multitareas...">
							<?php $__currentLoopData = $errors->get('cualidades'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="col-sm-6 text-center">
						<div class="border border-secondary bg-light rounded p-2 m-2">
							<label for="comentarios" class="">Comentarios extra:</label>
							<input id="comentarios" type="text" class=" text-center form-control <?php if( $errors->has('comentarios')): ?> is-invalid <?php endif; ?>" name="comentarios" value=" <?php if($proyecto->comentarios): ?><?php echo e($proyecto->comentarios); ?> <?php else: ?> <?php echo e(old('comentarios')); ?> <?php endif; ?>">
							<?php $__currentLoopData = $errors->get('comentarios'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>

				<div class="form-row">
					<div class="col-sm-12 mt-4">
						<button class="btn-primary btn btn-lg ml-4" type="submit"> 
							Guardar Cambios.
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>