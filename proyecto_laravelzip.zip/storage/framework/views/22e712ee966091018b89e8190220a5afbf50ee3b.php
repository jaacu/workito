<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-3">
		<div class="col-sm-12 mt-5">
			<div class="alert alert-primary text-center">
				<h1 class="alert-heading"><strong>La pagina que buscas no existe.</strong></h1>
				<hr>
				<p><a class="btn btn-primary btn-large" href="<?php echo e(route('home')); ?>">Volver a al inicio.</a></p>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>