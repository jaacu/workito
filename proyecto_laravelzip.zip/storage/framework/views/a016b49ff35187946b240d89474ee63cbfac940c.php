<div class="row my-2">
	<?php $__empty_1 = true; $__currentLoopData = $proyecto->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if( $loop->first ): ?>
	<div class="col-sm-12">
		<h3 class="text-center">Comentarios: </h3>
		<?php endif; ?>
		<?php echo $__env->make('comments.comment', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if($loop->last): ?>
	</div>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="col-sm-12">
		<div class="alert alert-info p-2">
			<h4 class="alert-heading text-center">No hay comentarios en este proyecto</h4>
		</div>
	</div>
	<?php endif; ?>
</div>