<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(env('APP_NAME','Workito')); ?></title>
    <!-- Styles -->
    
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    

    
    
</head>
<body>
    <div id="app" class="container">
        <nav class="navbar navbar-toggleable-md sticky-top">
            <a class=" navbar-brand mb-0 h1" <?php if(Auth::guest() ): ?> href="<?php echo e(route('inicio')); ?>" <?php else: ?> href="<?php echo e(route('home')); ?>" <?php endif; ?>> <?php echo e(env('APP_NAME','Workito')); ?></a>
            <?php if(Auth::guest()): ?>        
            <a class="  h4 nav-item nav-link" href="<?php echo e(route('login')); ?>">Inicar Sesión</a>
            <a class=" h4 nav-item nav-link" href="<?php echo e(route('register')); ?>">Registrarse</a>
            <?php else: ?>
            <button class="btn btn-outline-dark navbar-toggler navbar-toggler-right text-capitalize" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
            </button>
            <div class="collapse navbar-collapse text-center bg-light" id="navbarSupportedContent" style="">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item ">
                        <div>
                            <a class="dropdown-item" href="/user/perfil">Mi perfil</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo app('translator')->getFromJson('Logout'); ?>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </li>
                <?php if( Auth::user()->isAdmin() or Auth::user()->isDeveloper() ): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Notificaciones <span class="caret"></span>
                    </a>
                    <notifications :user="<?php echo e(Auth::user()->id); ?>"></notifications>
                </li>
                <?php endif; ?>
            </ul>
            <?php endif; ?>
        </div>
    </nav>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?> 
    <?php echo $__env->yieldContent('content'); ?>
    <br> <br> <br>


</div>

<script src="<?php echo e(mix('js/app.js')); ?>"></script>

<?php echo $__env->renderWhen( App\Http\Controllers\DeveloperController::devsScript() , 'dev.script' , array_except(get_defined_vars(), array('__data', '__path'))); ?>
</body>
</html>
