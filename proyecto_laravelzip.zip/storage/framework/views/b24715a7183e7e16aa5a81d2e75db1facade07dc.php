<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 my-3">
            <h3 class="text-center">
                Bienvenido <strong class="text-capitalize"><?php echo e(Auth::user()->name); ?></strong>!
            </h3>
        </div>
        <?php if( ! Auth::user()->isConfirmed()): ?>
        <div class="col-sm-12 my-3">
            <div class="aler alert-warning p-2">
                <br>
                <hr>
                <h4 class="alert-heading text-center">
                    Aun no has verificado tu cuenta, verificala <a class="alert-link" href="<?php echo e(route('user.confirmar')); ?>">ahora</a>.
                </h4>
                <h6 class="text-center">
                    No has recibido ningun correo? <a class="alert-link" href="<?php echo e(route('user.mail')); ?>">Reenviar correo</a>.
                </h6>
                <hr>
                <br>
            </div>
        </div>
        <?php else: ?>
        <div class="col-sm-8 my-3 mx-auto">
            <div class="card border-info ">
                <div class="card-body" >
                    <h5 class="card-title text-center text-capitalize"><a class="text-dark" data-toggle="collapse" href="#proyectos" role="button" aria-expanded="false" aria-controls="proyectos">Proyectos Creados: <span class="text-info"><?php echo e(Auth::user()->getProyects()->count()); ?></span></a> </h5>
                    <div class="collapse" id="proyectos">
                        <ul class="list-group list-group-flush bg-info ">
                            <li class="list-group-item border-info text-center">
                                Dossiers <strong><span class="text-info"><?php echo e(Auth::user()->dossiers->count()); ?></span></strong> <br>
                                <a href="<?php echo e(route('proyecto.dossier.crear')); ?>" class="btn btn-outline-primary">
                                    Crear un nuevo proyecto!
                                </a>
                            </li>
                            <li class="list-group-item border-info text-center">
                                Administracion De Redes Sociales <strong><span class="text-info"><?php echo e(Auth::user()->adminSocialNetworks->count()); ?></span></strong><br>
                                <a href="<?php echo e(route('proyecto.adminSocialNetworks.crear')); ?>" class="btn btn-outline-primary">
                                    Crear un nuevo proyecto!
                                </a>
                            </li>
                            <li class="list-group-item border-info text-center">
                                <a href="<?php echo e(route('proyecto.all')); ?>" class="btn btn-primary">Ver Todos Los Proyectos</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

             

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>