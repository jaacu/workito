<div class="col-sm-3"></div>
<div class="col-sm-6">
	<div class="row border border-secondary rounded p-2">
		<div class="col-sm-6 text-center">
			<p class=""> <strong class="text-dark"><?php echo e($user->name); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> <strong class="text-dark"><?php echo e($user->email); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Contacto: <strong class="text-dark"><?php echo e($user->contacto); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Cuenta de Skype: <strong class="text-dark"><?php echo e($user->cuentaSkype); ?></strong></p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Estado: <strong class="text-success">Desarrollador</strong></p>
		</div>
	</div>
	<div class="row my-2 ml-4">
		<div class="col-sm-6 my-2 p-2 text-center">
			<a class="btn btn-outline-info" href="<?php echo e(route('user.editar.admin', $user->id)); ?>">Editar.</a>
		</div>
		<div class="col-sm-6 my-2 p-2 text-center">
			<a href="<?php echo e(route('user.eliminar.admin', $user->id)); ?>" class="btn btn-outline-danger">Eliminar.</a>
		</div>		
	</div>
	<div class="col-sm-3"></div>
</div>
<div class="col-sm-12">
	<?php $__empty_1 = true; $__currentLoopData = $user->devs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if( $loop->first): ?>
	<div class="row">
		<div class="card-body border m-2 p-3">
			<div class="col-sm-12 my-3">
				<h3 class="card-title"><a class="text-info" style="text-decoration: none;" data-toggle="collapse" href="#cardproyectos" role="button" aria-expanded="false" aria-controls="cardproyectos"><span class="">
					Proyectos en los que esta trabajando:
				</span></a> </h3>
			</div>
			<div class="collapse" id="cardproyectos">
				<div id="accordion1" role="tablist">
					<?php endif; ?>
					<div class="card">
						<div class="card-header" role="tab" id="heading<?php echo e($loop->index); ?>">
							<h5 class="mb-0">
								<small class="mx-3 text-secondary text-muted">
									<?php echo e($dev->proyect->forHumansCreado()); ?>

								</small>
								<a class="collapsed mr-5 text-dark" data-toggle="collapse" href="#collapse<?php echo e($loop->index); ?>" role="button" aria-expanded="false" aria-controls="collapse<?php echo e($loop->index); ?>">
									<?php echo e($dev->proyect->nombre); ?>

								</a>
							</h5>
						</div>
						<div id="collapse<?php echo e($loop->index); ?>" class="collapse" role="tabpanel" aria-labelledby="heading<?php echo e($loop->index); ?>" data-parent="#accordion1">
							<a href="<?php echo e(route('proyecto.show', $dev->proyect->id)); ?>" style="display: block; text-decoration: none;">
								<div class="card-body">
									<?php if($dev->proyect->isTerminado()): ?>
									<div class="alert alert-success  w-50 mx-auto">
										<h5 class="text-center alert-heading">Proyecto Terminado</h5>
									</div>
									<?php else: ?>
									<div class="alert alert-info w-50 mx-auto">
										<h5 class="text-center alert-heading">Proyecto En Desarrollo</h5>
									</div>
									<?php endif; ?>
									<div class="text-center">
										<small class="text-danger">
											Fecha limite <br> <?php echo e($dev->proyect->fecha_limite); ?>

										</small>
									</div>
									<h4 class="text-dark text-center">
										Trabajado
									</h4>
									<?php echo $__env->make('dev.trabajado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
								</div>
							</a>
						</div>
					</div>
					<?php if($loop->last): ?>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<div class="row my-3">
			<div class="col-sm-12 alert alert-warning">
				<h3 class="alert-heading text-center">Este usuario aun no ha sido asignado a un proyecto!</h3>
				<p class="text-center">Aqui apareceran los proyectos que tenga asignado este asignado este usuario cuando tenga alguno.</p>
			</div>
		</div>
		<?php endif; ?>
	</div>
</div>
<?php echo $__env->make('comments.comentariosUser', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>