<?php $__env->startSection('content'); ?>
<div class="container">
	<?php $__empty_1 = true; $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if($loop->first): ?>
	<div class="row">
		<div class="col-sm-6">
			<h3 class="text-dark text-center">Proyectos</h3>
		</div>
		<div class="col-sm-6">
			<?php echo $__env->make('searchBar', ['action' =>route('proyecto.buscar')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
	<div class="row my-4">
		<?php endif; ?>
		<?php echo $__env->make('proyecto.proyectoMIN', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if($loop->last): ?>
	</div>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="row mt-4">
		<div class="col-sm-12 alert alert-warning">
			<h4 class="alert-heading">Parece que no hay ningun proyecto!</h4>
			<hr>
			<a href="<?php echo e(route('proyecto.crear')); ?>" class="btn btn-primary">Crear un nuevo proyecto ahora.</a>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>