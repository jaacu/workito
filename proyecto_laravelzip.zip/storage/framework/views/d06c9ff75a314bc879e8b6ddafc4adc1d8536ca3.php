<div class="col-sm-3"></div>
<div class="col-sm-6">
	<div class="row border border-secondary rounded p-2">
		<div class="col-sm-6 text-center">
			<p class=""> <strong class="text-dark"><?php echo e($user->name); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> <strong class="text-dark"><?php echo e($user->email); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> NIF: <strong class="text-dark"><?php echo e($user->NIF); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Contacto: <strong class="text-dark"><?php echo e($user->contacto); ?></strong> </p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Cuenta de Skype: <strong class="text-dark"><?php echo e($user->cuentaSkype); ?></strong></p>
		</div>
		<div class="col-sm-6 text-center">
			<p class=""> Estado: <strong class="text-success">Cliente</strong></p>
		</div>
		<div class="col-sm-12">
			<?php if( $user->confirmed ): ?>
			<p>Firma Digital: <strong class="text-dark"><?php echo e($user->digital_sign); ?></strong></p>
			<?php else: ?>
			<div class="alert alert-danger" role="alert">
				<h5 class="alert-heading ml-2">Este usuario aun no ha verificado su cuenta!</h5>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<div class="row my-2 ml-4">
		<div class="col-sm-6 my-2 p-2 text-center">
			<a class="btn btn-outline-info" href="<?php echo e(route('user.editar.admin', $user->id)); ?>">Editar.</a>
		</div>
		<div class="col-sm-6 my-2 p-2 text-center">
			<a href="<?php echo e(route('user.eliminar.admin', $user->id)); ?>" class="btn btn-outline-danger">Eliminar.</a>
		</div>		
	</div>
	<div class="col-sm-3"></div>
</div>
<div class="col-sm-12 mb-5">
	<div class="col-sm-12">
		<?php if( $user->hasProyects() ): ?>
		<div class="row">
			<div class="col-sm-12 text-info">
				<h3>Proyectos creados por este usuario:</h3>
			</div>
			<div class="col-sm-12">
				<?php $__currentLoopData = $user->getProyects(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($loop->first): ?>
				<div id="accordion1" role="tablist">
					<?php endif; ?>			
					<div class="card">
						<div class="card-header" role="tab" id="heading<?php echo e($loop->index); ?>">
							<h5 class="mb-0">
								<small class="mx-3 text-secondary text-muted">
									<?php if( $proyecto instanceof App\Dossier ): ?>
									Dossier
									<?php endif; ?>
									<?php if( $proyecto instanceof App\adminSocialNetwork ): ?>
									Administracion De Redes Sociales
									<?php endif; ?>
								</small>
								<a class="collapsed mr-5 text-dark" data-toggle="collapse" href="#collapse<?php echo e($loop->index); ?>" role="button" aria-expanded="false" aria-controls="collapse<?php echo e($loop->index); ?>">
									<?php echo e($proyecto->nombre); ?>

								</a>
								<?php if( $proyecto->encontrar() ): ?>
								<a href="<?php echo e(route('proyecto.show',$proyecto->encontrar()->id )); ?>" 
									class="btn btn-outline-primary ml-4">
									<?php if($proyecto->encontrar()->isTerminado() ): ?> Proyecto Terminado <?php else: ?> Proyecto en desarrollo. <?php endif; ?></a>
									<?php else: ?>
									<a href="<?php echo e(route('proyecto.asignar',[$proyecto->getType(),$proyecto->id ])); ?>" class="btn btn-outline-primary ml-4">Asignar proyecto.</a>
									<?php endif; ?>
								</h5>
							</div>
							<div id="collapse<?php echo e($loop->index); ?>" class="collapse" role="tabpanel" aria-labelledby="heading<?php echo e($loop->index); ?>" data-parent="#accordion1">
								<div class="card-body">
									<?php echo $__env->renderWhen( ($proyecto instanceof App\Dossier)  ,'proyecto.proyectoDossier', array_except(get_defined_vars(), array('__data', '__path'))); ?>
									<?php echo $__env->renderWhen( ($proyecto instanceof App\adminSocialNetwork)  ,'proyecto.proyectoAdmSN', array_except(get_defined_vars(), array('__data', '__path'))); ?>
									
								</div>
							</div>
						</div>
						<?php if($loop->last): ?>
					</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<?php else: ?>
			<div class="row my-3">
				<div class="col-sm-12 alert alert-warning">
					<h3 class="alert-heading text-center">Este usuario aun no ha creado ningun proyecto!</h3>
					<p class="text-center">Aqui apareceran los proyectos de este usuario cuando tenga alguno.</p>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<br> <br> <br>