
<div class="col-sm-3  text-dark ">
	<a href="<?php echo e(route('user',$user->id)); ?>" style="display: block; text-decoration: none;" class="m-2">
		<div class="rounded p-2 border  border-<?php echo e($user->getRoleColor()); ?>">
			<p class="text-dark"><?php echo e($user->name); ?></p>
			<p><span class="text-<?php echo e($user->getRoleColor()); ?>"><?php echo e($user->getRoleString()); ?></span></p>
		</div>
	</a>
</div>
