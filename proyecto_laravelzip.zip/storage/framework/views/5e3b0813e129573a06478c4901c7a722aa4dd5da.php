<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-3">
		<div class="col-sm-12">
			<h1 class="text-center text-capitalize">Datos:</h1>
		</div>
		<div class="col-sm-12">
			<form action="<?php echo e(route('user.edit')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="name" class="">Nombre</label>
						<input id="name" type="text" class="form-control <?php if( $errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" required autofocus>
						<?php if( $errors->has('name') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('name')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="email" class="">Correo Electronico</label>
						<input id="email" type="email" class="form-control <?php if( $errors->has('email')): ?> is-invalid <?php endif; ?>" name="email" value="<?php echo e(Auth::user()->email); ?>" required>
						<?php if( $errors->has('email') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('email')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<?php if (! ( Auth::user()->isAdmin())): ?>
				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="contacto" class="">Contacto</label>
						<input id="contacto" type="text" class="form-control <?php if( $errors->has('contacto')): ?> is-invalid <?php endif; ?>" name="contacto" value="<?php echo e(Auth::user()->contacto); ?>" required>
						<?php if( $errors->has('contacto') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('contacto')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="cuentaSkype" class="">Skype</label>
						<input id="cuentaSkype" type="text" class="form-control <?php if( $errors->has('cuentaSkype')): ?> is-invalid <?php endif; ?>" name="cuentaSkype" value="<?php echo e(Auth::user()->cuentaSkype); ?>" required>
						<?php if( $errors->has('cuentaSkype') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('cuentaSkype')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<?php endif; ?>
				<?php if( Auth::user()->isClient() ): ?>
				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="NIF" class="">NIF</label>
						<input id="NIF" type="text" class="form-control <?php if( $errors->has('NIF')): ?> is-invalid <?php endif; ?>" name="NIF" value="<?php echo e(Auth::user()->NIF); ?>" required>
						<?php if( $errors->has('NIF') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('NIF')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<?php endif; ?>
				<div class=" form-row my-3 ">
					<div class="col-sm-6 mx-auto"> 
						<button class="btn btn-lg btn-primary text-center" type="submit">
							Guardar Cambios
						</button>
					</div>
				</div>

			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>