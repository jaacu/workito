<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-2">
		<div class="col-sm-12">
			<h3 class="text-center text-primary">Datos del <a href="<?php echo e(route('admin.users')); ?>">Usuario</a>:</h3>
		</div>
		<?php if( $user->isAdmin() ): ?>
		<?php echo $__env->make('user.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>

		<?php if( $user->isDeveloper() ): ?>
		<?php echo $__env->make('user.dev', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>

		<?php if( $user->isClient() ): ?>	
		<?php echo $__env->make('user.client', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>
	</div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>