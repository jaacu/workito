<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row mt-2">
      <div class="col-sm-12">
        <h3 class="text-center text-primary">Inicio de Sesión</h3>
    </div>
    <div class="col-sm-12">
        <form method="POST" action="<?php echo e(route('login')); ?>" class="">
            <div class="">
                <?php echo e(csrf_field()); ?>

                <div class=" form-row ">
                    <div class="col-sm-4 mx-auto"> 
                        <label for="email" class="">Correo Electronico</label>
                        <input id="email" type="email" class="form-control <?php if( $errors->has('email')): ?> is-invalid <?php endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php if( $errors->has('email') ): ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($errors->first('email')); ?></strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class=" form-row ">
                    <div class="col-sm-4 mx-auto"> 
                        <label for="password" class="">Contraseña</label>
                        <input id="password" type="password" class="form-control <?php if( $errors->has('password')): ?> is-invalid <?php endif; ?>" name="password" value="<?php echo e(old('password')); ?>"  required>
                        <?php if( $errors->has('password') ): ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($errors->first('password')); ?></strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div> 

                <div class="form-row">
                    <div class="col-sm-4 mx-auto">
                        <div class="form-check">
                            <input class="form-check-input ml-1" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember"> Recuerdame </label>                            
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-sm-4 mx-auto">
                        <button type="submit" class="btn btn-primary">
                            Entrar
                        </button>

                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            ¿Olvidaste tu contraseña?
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>