<?php $__env->startSection('content'); ?>
<div class="container">
	<?php $__empty_1 = true; $__currentLoopData = $devs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if( $loop->first): ?>
	<div class="row my-2">
		<div class="col-sm-12">
			<div>
				<form action="<?php echo e(route('proyecto.custom.crear')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="form-row my-3 p-2">
						<div class="col-sm-8 text-center mx-auto"> 
							<label for="name" class="">Nombre del proyecto:</label>
							<input id="name" type="text" class="form-control <?php if( $errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
							<?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="form-row my-3 p-2">
						<div class="col-sm-4 text-center mx-auto"> 
							<label for="fecha_limite" class="">Fecha limite:</label>
							<input id="fecha_limite" type="date" class="form-control <?php if( $errors->has('fecha_limite')): ?> is-invalid <?php endif; ?>" name="fecha_limite" value="<?php echo e(old('fecha_limite')); ?>" required >
							<?php $__currentLoopData = $errors->get('fecha_limite'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="form-row my-3 p-2">
						<div class="col-sm-8 text-center mx-auto"> 
							<label for="dev" class="">Desarrolladores registrados:</label>
							<select name="dev[]" id="dev" class="selectpicker show-tick form-control <?php if( $errors->has('dev')): ?> is-invalid <?php endif; ?>" multiple title="Desarrolladores..." data-live-search="true" data-selected-text-format="count > 3" data-size="7" data-actions-box="true" data-header="Selecciona 1 o mas desarrolladores." required>
								<?php endif; ?>
								<option value="<?php echo e($dev->id); ?>" data-tokens="<?php echo e($dev->name); ?>" ><?php echo e($dev->name); ?></option>
								<?php if( $loop->last): ?>	
							</select>
							<?php $__currentLoopData = $errors->get('dev'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						</div>
					</div>
					<div class="form-row my-3 p-2">
						<div class="col-sm-7 text-center mx-auto"> 
							<label for="descripcion" class="">Descripcion:</label>
							<textarea id="descripcion" type="date" class="form-control <?php if( $errors->has('descripcion')): ?> is-invalid <?php endif; ?>" name="descripcion" value="<?php echo e(old('descripcion')); ?>" required cols="50" rows="4" placeholder="Descripcion" ></textarea>
							<?php $__currentLoopData = $errors->get('descripcion'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<input class="form-control" type="hidden" name="type" value="2"> 
					<input class="form-control" type="hidden" name="id" value="0">
					<div class="form-row my-3">
						<div class="col-sm-6 mx-auto">
							<button type="submit" class="btn btn-primary btn-lg">
								Crear.
							</button>
						</div>
					</div>
				</form>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="row my-5">
		<div class="alert alert-warning p-3 rounded col-sm-12 text-center my-3">
			<h4 class="alert-heading">Parece que no hay desarrolladores registrados.</h4>
		</div>
		<div class="mx-auto col-sm-8 p-2 text-center ">
			<div class="p-3">
				<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-lg btn-primary mr-2">Usuarios Registrados.</a>
				<a href="<?php echo e(route('home')); ?>" class="btn btn-lg btn-primary ml-2">Volver a la pagina principal.</a>
			</div>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>