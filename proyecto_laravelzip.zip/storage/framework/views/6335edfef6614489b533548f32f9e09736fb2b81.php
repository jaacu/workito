<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12 my-2">
			<h1>Editando: "<?php echo e($proyecto->nombre); ?>"</h1>
		</div>
		<div class="col-sm-12 my-2">
			<?php if( $errors->has('facebook')  and $errors->has('twitter') and $errors->has('instagram') ): ?>
			<div class="alert-danger alert">
				Por favor seleccione al menos una red social.
			</div>
			<?php endif; ?>
			<div class="">
				<form action="<?php echo e(route('proyecto.adminSocialNetworks.edit',$proyecto->id)); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					
					<div class="form-row">
						<div class="col-sm-8 text-center mx-auto"> 
							<label for="nombre" class="">Nombre de la empresa o persona:</label>
							<input id="nombre" type="text" class="form-control <?php if( $errors->has('nombre')): ?> is-invalid <?php endif; ?>" name="nombre" value="<?php echo e($proyecto->nombre); ?>" required autofocus>
							<?php $__currentLoopData = $errors->get('nombre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($error); ?></strong>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<div class="border rounded border-secondary my-2 p-2">
						<div class="form-row">
							<div class="col-sm-8 text-center mx-auto"> 
								<div class="form-check mt-2">
									<label for="facebook" class="form-check-label " > Facebook:</label>
									<input id="facebook" type="checkbox" value="1" class="form-check-input ml-3" name="facebook" <?php if( $proyecto->facebook): ?> checked <?php endif; ?>>
								</div>
							</div>
						</div>
						<div class="" id="facebookBox">
							<div class="form-row m-3 p-3">
								<div class="col-sm-12 text-center"> 
									<label for="fbPermisosCompra" class="">Facebook Permisos de Compra:</label>
									<input id="fbPermisosCompra" type="text" class=" text-center form-control <?php if( $errors->has('fbPermisosCompra')): ?> is-invalid <?php endif; ?>" name="fbPermisosCompra" value="<?php echo e($proyecto->fbPermisosCompra); ?>" >
									<?php $__currentLoopData = $errors->get('fbPermisosCompra'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="invalid-feedback">
										<strong> <?php echo e($error); ?></strong>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
					</div>
					<div class="border rounded border-secondary my-2 p-2">
						<div class="form-row">
							<div class="col-sm-8 text-center mx-auto"> 
								<div class="form-check mt-2">
									<label for="twitter" class="form-check-label " >Twitter:</label>
									<input id="twitter" type="checkbox" value="1" class="form-check-input ml-3 text-center" name="twitter" <?php if( $proyecto->twitter): ?> checked <?php endif; ?>>
								</div>
							</div>
						</div>

						<div class="form-row m-3 p-2">
							<div class="col-sm-6 text-center"> 
								<label for="twEmail" class="">Email de Twitter:</label>
								<input id="twEmail" type="email" class="text-center form-control <?php if( $errors->has('twEmail')): ?> is-invalid <?php endif; ?>" name="twEmail" value="<?php echo e($proyecto->twEmail); ?>" >
								<?php $__currentLoopData = $errors->get('twEmail'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="invalid-feedback">
									<strong> <?php echo e($error); ?></strong>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>

							<div class="col-sm-6 text-center"> 
								<label for="twPassword" class="">Contraseña de Twitter:</label>
								<input id="twPassword" type="text" class="text-center form-control <?php if( $errors->has('twPassword')): ?> is-invalid <?php endif; ?>" name="twPassword" value="<?php echo e($proyecto->twPassword); ?>" >
								<?php $__currentLoopData = $errors->get('twPassword'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="invalid-feedback">
									<strong> <?php echo e($error); ?></strong>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
					
					<div class="border rounded border-secondary my-2 p-2">
						<div class="form-row">
							<div class="col-sm-8 text-center mx-auto"> 
								<div class="form-check mt-2">
									<label for="instagram" class="form-check-label " >Instagram:</label>
									<input id="instagram" type="checkbox" value="1" class="form-check-input ml-3" name="instagram" <?php if( $proyecto->instagram): ?> checked <?php endif; ?>>
								</div>
							</div>
						</div>

						<div class="form-row m-3 p-2">
							<div class="col-sm-6 text-center"> 
								<label for="instEmail" class="">Email de Instagram:</label>
								<input id="instEmail" type="email" class="text-center form-control <?php if( $errors->has('instEmail')): ?> is-invalid <?php endif; ?>" name="instEmail" value="<?php echo e($proyecto->instEmail); ?>" >
								<?php $__currentLoopData = $errors->get('instEmail'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="invalid-feedback">
									<strong> <?php echo e($error); ?></strong>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>

							<div class="col-sm-6 text-center"> 
								<label for="instPassword" class="">Contraseña de Twitter:</label>
								<input id="instPassword" type="text" class=" text-center form-control <?php if( $errors->has('instPassword')): ?> is-invalid <?php endif; ?>" name="instPassword" value="<?php echo e($proyecto->instPassword); ?>" >
								<?php $__currentLoopData = $errors->get('instPassword'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="invalid-feedback">
									<strong> <?php echo e($error); ?></strong>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>

					<div class="form-row">
						<div class="col-sm-12 mt-4 ">
							<button class="btn-primary btn btn-lg" type="submit"> 
								Guardar Cambios.
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>