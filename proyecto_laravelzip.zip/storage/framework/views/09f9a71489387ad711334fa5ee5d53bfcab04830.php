<?php $__empty_1 = true; $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php if( $loop->first): ?>
<div class="alert alert-danger" role="alert">
	<h3 class="alert-heading ml-2">Parece ser que hay algunos errores!</h3>
	<?php endif; ?>
	<p><?php echo e($error); ?></p>
	<?php if( $loop->last): ?>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<?php endif; ?>