<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-5">
        <div class=" mx-auto col-md-12">
            <?php echo $__env->make('debug', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h3 class="text-dark text-center">Bienvenido <?php echo e(Auth::user()->name); ?></h3>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-sm-6">
            <div class="card border-info ">
                <div class="card-body" >
                    <h5 class="card-title"><a class="text-dark" data-toggle="collapse" href="#proyectos" role="button" aria-expanded="false" aria-controls="proyectos">Proyectos Activos: <span class="text-info"><?php echo e($proyects->count()); ?></span></a> </h5>
                    <div class="collapse" id="proyectos">
                        <ul class="list-group list-group-flush bg-info ">
                    
                    <li class="list-group-item border-info">
                        <a href="<?php echo e(route('admin.proyectos')); ?>" class="btn btn-primary">Ver Proyectos.</a>
                        <a href="<?php echo e(route('proyecto.crear')); ?>" class="btn btn-primary">Crear Nuevo Proyecto.</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-6">
    <div class="card border-info ">
        <div class="card-body" >
            <h5 class="card-title"><a class="text-dark" data-toggle="collapse" href="#usuarios" role="button" aria-expanded="false" aria-controls="usuarios">Usuarios registrados: <span class="text-info"><?php echo e($users->count()); ?></span></a> </h5>
            <div class="collapse" id="usuarios">
                <ul class="list-group list-group-flush bg-info ">
                    <li class="list-group-item border-info" >
                        Administradores: <strong><span class="text-info"><?php echo e($users->where('role', 0)->except(['id' => Auth::user()->id])->count()); ?></span></strong>
                    </li>
                    <li class="list-group-item border-info">
                        Desarrolladores: <strong><span class="text-info"><?php echo e($users->where('role', 1)->except(['id' => Auth::user()->id])->count()); ?></span></strong>
                    </li>
                    <li class="list-group-item border-info" >
                        Clientes: <strong><span class="text-info"><?php echo e($users->where('role', 2)->except(['id' => Auth::user()->id])->count()); ?></span></strong>
                    </li>
                    <li class="list-group-item border-info">
                        <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-primary">Ver Usuarios.</a>
                        <a href=" <?php echo e(route('user.crear.admin')); ?>" class="btn btn-primary">Crear un nuevo usuario.</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>