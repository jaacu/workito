<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-2">
		<div class="col-sm-12">
			<h3 class="text-center text-primary">
				Creacion de un nuevo usuario.
			</h3>
		</div>
		<div class="col-sm-12">
			<form action="<?php echo e(route('user.create.admin')); ?>" method="POST">
				<?php echo $__env->make('debug', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('user.crear', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div>
					<div class=" form-row ">
						<div class="col-sm-6 mx-auto"> 
							<label for="password" class="">Contraseña</label>
							<input id="password" type="text" class="form-control <?php if( $errors->has('password')): ?> is-invalid <?php endif; ?>" name="password" required>
							<?php if( $errors->has('password') ): ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($errors->first('password')); ?></strong>
							</div>
							<?php endif; ?>
						</div>
					</div>

					<div class=" form-row ">
						<div class="col-sm-6 mx-auto w-50"> 
							<label for="role" class="">Rol</label>
							<select name="role" id="select" class="selectpicker form-control" required title="Roles" data-header="Selecciona el rol."> 
								<option value="1" > Desarrollador. </option>
								<option value="2" > Cliente. </option>
								<option value="0"> Admin. </option>
							</select>
							<?php if( $errors->has('role') ): ?>
							<div class="invalid-feedback">
								<strong> <?php echo e($errors->first('role')); ?></strong>
							</div>
							<?php endif; ?>
						</div>
					</div>

					<div class="form-row mt-3">
						<div class="col-sm-6 mx-auto">
							<button type="submit" class="btn btn-primary btn-lg">
								Crear
							</button>
						</div>
					</div>

				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>