<div class="card col-sm-3 border-0">
	<div class="card-body border-dark <?php if( $proyecto->encontrar() ): ?> <?php if( $proyecto->encontrar()->isTerminado() ): ?>  bg-success <?php else: ?> bg-info <?php endif; ?> <?php else: ?> bg-danger <?php endif; ?> m-2 p-3 border  rounded">
		<h5 class="card-title text-center"><a class="text-dark" style="text-decoration: none;" data-toggle="collapse" href="#card<?php echo e($loop->index); ?>" role="button" aria-expanded="false" aria-controls="card<?php echo e($loop->index); ?>"><span class=" text-dark">
			<?php if( $proyecto->encontrar() ): ?>
			<?php echo e($proyecto->encontrar()->nombre); ?>

			<?php else: ?>
			<?php echo e($proyecto->nombre); ?>

			<?php endif; ?>
		</span></a> </h5>
		<div class="collapse <?php if( $proyecto->encontrar() ): ?> <?php if( $proyecto->encontrar()->isTerminado() ): ?>  bg-success <?php else: ?> bg-info <?php endif; ?> <?php else: ?> bg-danger <?php endif; ?>" id="card<?php echo e($loop->index); ?>">
			<ul class="list-group list-group-flush">
				<?php if( $proyecto->encontrar() ): ?>
				<a href="<?php echo e(route('proyecto.show', $proyecto->encontrar()->id )); ?>" style="display: block; text-decoration: none;">
					<li class="list-group-item bg-light border-0 text-center" style="border-top-left-radius: 60%; ">
						<span class=" text-danger"><?php echo e($proyecto->encontrar()->fecha_limite); ?></span>
					</li>
					<li class="list-group-item bg-light border-0 text-center" style="border-bottom-right-radius: 60%">
						<span class="text-dark"> Desarrolladores:</span> <span class="badge badge-pill badge-info"> <?php echo e($proyecto->encontrar()->devs->count()); ?></span>
					</li>
				</a>
				<?php else: ?>
				<a href="<?php echo e(route('proyecto.show.type', [ $proyecto->getType() , $proyecto->id ] )); ?>" style="display: block; text-decoration: none;">
					<li class="list-group-item bg-light border-0 text-center" style="border-top-left-radius: 60%; border-bottom-right-radius: 60%">
						<span class="text-dark"> Por: <strong><?php echo e($proyecto->user->name); ?> </strong>.</span>
					</li>
				</a>
				<?php endif; ?>
			</ul>
		</div>
	</div>
</div>