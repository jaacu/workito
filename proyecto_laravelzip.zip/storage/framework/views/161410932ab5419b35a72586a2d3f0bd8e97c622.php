<?php $__env->startSection('content'); ?>
<div class="container mt-3">
	
	<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if( $loop->first): ?>
	<?php echo $__env->make('debug', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row mt-2">
		<div class="col-sm-6">
			<h1 class=" ml-3 text-center">Resultados </h1>
		</div>
		<div class="col-sm-6 text-center">
			<a href="<?php echo e($url); ?>" class="btn btn-outline-dark center-block btn-lg  ">Volver</a>
		</div>
	</div>
	<hr class="mt-2 mb-2">
	<div class="row clearfix">
		<?php endif; ?>
		<?php echo $__env->renderWhen( ($item instanceof App\Proyect)  ,'proyecto.proyectoMIN', [ 'proyecto' => $item->encontrar()], array_except(get_defined_vars(), array('__data', '__path'))); ?>
		<?php echo $__env->renderWhen( ($item instanceof App\Dossier or $item instanceof App\adminSocialNetwork )  ,'proyecto.proyectoMIN', [ 'proyecto' => $item], array_except(get_defined_vars(), array('__data', '__path'))); ?>
		<?php echo $__env->renderWhen( ($item instanceof App\User)  ,'user.userMIN', [ 'user' => $item], array_except(get_defined_vars(), array('__data', '__path'))); ?>
		<?php echo $__env->renderWhen( ($item instanceof App\Dev)  ,'dev.proyectDevMIN', [ 'dev' => $item], array_except(get_defined_vars(), array('__data', '__path'))); ?>
		<?php if($loop->last): ?>
	</div>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="row my-5">
		<div class="col-sm-12 alert alert-warning">
			<h3 class="alert-heading">No se ha encontrado ningun resultado, cambio la busqueda e intentalo de nuevo!</h3>
		</div>
		<div class="col-sm-12 text-center my-5">
			<a href="<?php echo e($url); ?>" class="btn btn-outline-dark center-block btn-lg  ">Volver</a>
		</div>
	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>