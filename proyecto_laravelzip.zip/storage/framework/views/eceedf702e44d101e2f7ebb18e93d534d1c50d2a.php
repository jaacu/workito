
	<div class="border w-70 mx-auto p-2 m-2 rounded">
		<?php if( Auth::user()->isAdmin() ): ?>
		<small class="text-muted"><a href="<?php echo e(route('user', $comment->user->id )); ?>" style="text-decoration: none;" class=""><span class="text-<?php echo e($comment->user->getRoleColor()); ?>"><?php echo e($comment->user->name); ?></span></a> dijo...</small>
		<?php else: ?>
		<small class="text-muted"><span class="text-<?php echo e($comment->user->getRoleColor()); ?>"><?php echo e($comment->user->name); ?></span> dijo...</small> 
		
		<?php endif; ?>
		<p class="mb-0"><?php echo e($comment->texto); ?></p>
		<small class="text-muted"> Comentado <?php echo e($comment->forHumansCreado()); ?>. </small>
		<?php if( $comment->isEditado() ): ?>
		<br><small class="text-muted">Editado <?php echo e($comment->forHumansEditado()); ?></small>
		<?php endif; ?>
		<br>
		<?php if (! ( $comment->proyect->isTerminado())): ?>
		<?php if(Auth::user()->id === $comment->user->id): ?>
		<a href="<?php echo e(route('comentario.editar', $comment->id)); ?>" class="btn-info btn">Editar</a>
		<?php endif; ?>
		<?php if( Auth::user()->id === $comment->user->id or Auth::user()->isAdmin() ): ?>
		<a href="<?php echo e(route('comentario.eliminar', $comment->id)); ?>" class="btn-danger btn" >Eliminar</a>
		<?php endif; ?>
		<?php endif; ?>
	</div>
