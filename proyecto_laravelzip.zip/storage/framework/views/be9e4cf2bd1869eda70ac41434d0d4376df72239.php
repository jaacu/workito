<div class="row">
	<div class="col-sm-12">
		<h4 class="text-center"> Nombre Empresa: <a class="text-dark" href="<?php echo e(route('proyecto.show.type',[$proyecto->getType(),$proyecto->id])); ?>"><?php echo e($proyecto->nombre); ?></a></h4>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">
			<p>Descripcion de la empresa: <br><strong class="text-dark"><?php echo e($proyecto->queEs); ?></strong></p>	
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Hacia que publico va dirigido: <br><strong class="text-dark"><?php echo e($proyecto->publico); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Mision de la empresa: <br><strong class="text-dark"><?php echo e($proyecto->mision); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Vision de la empresa: <br><strong class="text-dark"><?php echo e($proyecto->vision); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Valores de la empresa: <br><strong class="text-dark"><?php echo e($proyecto->valores); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Que servicios ofrece la empresa: <br><strong class="text-dark"><?php echo e($proyecto->servicios); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Proyecciones de crecimiento: <br><strong class="text-dark"><?php echo e($proyecto->crecimiento); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Que se puede encontrar en la empresa: <br><strong class="text-dark"><?php echo e($proyecto->que_se_puede_encontrar); ?></strong></p>
		</div>
	</div>
	<div class="col-sm-4 mt-4">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Cualidades que describen la empresa: <br><strong class="text-dark"><?php echo e($proyecto->cualidades); ?></strong></p>
		</div>
	</div>
	<?php if( $proyecto->comentarios): ?>
	<div class="col-sm-8 mt-4 mx-auto">
		<div class="border rounded p-2 h-100 border-info text-justify">	
			<p>Comentarios extra: <br><strong class="text-dark"><?php echo e($proyecto->comentarios); ?></strong></p>
		</div>
	</div>
	<?php endif; ?>
	<?php if( Auth::user()->isAdmin() or Auth::user()->id == $proyecto->user->id ): ?>
	<div class="col-sm-12 mt-3 text-center">
		<a href="<?php echo e(route('proyecto.dossier.editar', $proyecto->id)); ?>" class="btn btn-info w-25 text-center">Editar.</a>
	</div>
	<?php endif; ?>
</div>