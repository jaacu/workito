<form action="<?php echo e($action); ?>" role="search" class="form-inline">
	<input  class="form-control" type="text" placeholder="Buscar.." name="query"  autofocus="autofocus">
	<button class="btn btn-outline-dark ml-1" type="submit">Buscar</button>
</form>
