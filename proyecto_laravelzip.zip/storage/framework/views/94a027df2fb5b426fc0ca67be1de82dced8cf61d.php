<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row my-4">		
		<div class="col-sm-12">			
			<div class="alert alert-danger">
				<h3 class="alert-heading">
					<strong>Advertencia!</strong>
				</h3>
				<h6>
					Al momento de editar este usuario tenga en cuenta que si cambia el <strong>estado</strong> o la <strong>contraseña</strong> se perderan todos los datos de proyectos y comentarios relacionados con este usuario. 
				</h6>
				<?php echo $__env->make('user.conteoMIN', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<h4><strong>Todos estos datos se perdaran.</strong></h4>
			</div>
			<p><span style="color: red;"></span> </p>
			<form action="<?php echo e(route('user.edit.admin', $user->id)); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="name" class="">Nombre</label>
						<input id="name" type="text" class="form-control <?php if( $errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" value="<?php echo e($user->name); ?>" required autofocus>
						<?php if( $errors->has('name') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('name')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="email" class="">Correo Electronico</label>
						<input id="email" type="text" class="form-control <?php if( $errors->has('email')): ?> is-invalid <?php endif; ?>" name="email" value="<?php echo e($user->email); ?>"  required>
						<?php if( $errors->has('email') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('email')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="NIF" class="">NIF</label>
						<input id="NIF" type="text" class="form-control <?php if( $errors->has('NIF')): ?> is-invalid <?php endif; ?>" name="NIF" value="<?php echo e($user->NIF); ?>"  required>
						<?php if( $errors->has('NIF') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('NIF')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="contacto" class="">Contacto</label>
						<input id="contacto" type="text" class="form-control <?php if( $errors->has('contacto')): ?> is-invalid <?php endif; ?>" name="contacto" value="<?php echo e($user->contacto); ?>"  required>
						<?php if( $errors->has('contacto') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('contacto')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="cuentaSkype" class="">Cuenta de Skype</label>
						<input id="cuentaSkype" type="text" class="form-control <?php if( $errors->has('cuentaSkype')): ?> is-invalid <?php endif; ?>" name="cuentaSkype" value="<?php echo e($user->cuentaSkype); ?>"  required>
						<?php if( $errors->has('cuentaSkype') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('cuentaSkype')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>

				<div class=" form-row ">
					<div class="col-sm-6 mx-auto"> 
						<label for="password" class="">Contraseña</label>
						<input id="password" type="text" class="form-control <?php if( $errors->has('password')): ?> is-invalid <?php endif; ?>" name="password" value="<?php echo e(old('password')); ?>">
						<?php if( $errors->has('password') ): ?>
						<div class="invalid-feedback">
							<strong> <?php echo e($errors->first('password')); ?></strong>
						</div>
						<?php endif; ?>
					</div>
				</div>
				
				<div class=" form-row ">
					<div class="col-sm-6 mx-auto">
						<p>Estado actual: 
							<?php if( $user->isDeveloper()): ?>
							Desarrollador.
							<?php endif; ?>

							<?php if( $user->isClient()): ?>
							Cliente.
							<?php endif; ?>
						</p> 
						<label for="role" class="">Nuevo estado</label>
						<select id="role" class="form-control" name="role" required>
							<option value="1" <?php if($user->isDeveloper() ): ?> selected <?php endif; ?>> Desarrollador. </option>
							<option value="2" <?php if($user->isClient() ): ?> selected <?php endif; ?>> Cliente. </option>
							<option value="0"> Admin. </option>
						</select>
					</div>
				</div>
				<div class="form-row my-3">
					<div class="col-sm-6 text-right">
						<button type="submit" class=" mr-2 btn btn-primary btn-lg">
							Guardar Cambios
						</button>
					</div>
					<div class="col-sm-6 text-left ">
						<a href="<?php echo e(route('user', $user->id)); ?>" class="btn btn-dark ml-2 btn-lg">Volver al perfil.</a>
					</div>
				</div>

			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>