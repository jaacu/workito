<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 my-3">
            <h4 class="text-capitalize text-center text-dark">Restablecer Contraseña</h4>
        </div>
        <div class="col-sm-12">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('password.request')); ?>">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <div class="form-row">
                    <div class="col-sm-5 text-center mx-auto"> 
                        <label for="email" class="">Correo Electronico:</label>
                        <input id="email" type="email" class="form-control <?php if( $errors->has('email')): ?> is-invalid <?php endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($error); ?></strong>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-sm-5 text-center mx-auto"> 
                        <label for="password" class="">Contraseña:</label>
                        <input id="password" type="password" class="form-control <?php if( $errors->has('password')): ?> is-invalid <?php endif; ?>" name="password" required>
                        <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($error); ?></strong>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-sm-5 text-center mx-auto"> 
                        <label for="password-confirm" class="">Confirmar Contraseña:</label>
                        <input id="password-confirm" type="password" class="form-control <?php if( $errors->has('password_confirmation')): ?> is-invalid <?php endif; ?>" name="password_confirmation" required>
                        <?php $__currentLoopData = $errors->get('password_confirmation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($error); ?></strong>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-row my-3">
                    <div class="col-md-5 mx-auto">
                        <button type="submit" class="btn btn-primary">
                            Restablecer Contraseña
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>