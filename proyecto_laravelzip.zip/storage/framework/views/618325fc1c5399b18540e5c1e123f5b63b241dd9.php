<div class="card col-sm-6 border-0">
	<div class="card-body border-dark <?php if( $dev->proyect->isTerminado() ): ?>  bg-success <?php else: ?> bg-info <?php endif; ?> m-2 p-3 border  rounded">
		<h5 class="card-title text-center"><a class="text-dark" style="text-decoration: none;" data-toggle="collapse" href="#card<?php echo e($loop->index); ?>" role="button" aria-expanded="false" aria-controls="card<?php echo e($loop->index); ?>"><span class=" text-dark">
			<?php echo e($dev->proyect->nombre); ?>

		</span></a> </h5>
		<div class="collapse <?php if( $dev->proyect->isTerminado() ): ?>  bg-success <?php else: ?> bg-info <?php endif; ?>" id="card<?php echo e($loop->index); ?>">
			<ul class="list-group list-group-flush">
				<a href="<?php echo e(route('proyecto.show', $dev->proyect->id )); ?>" style="display: block; text-decoration: none;">
					<li class="list-group-item bg-light border-0 text-center" style="border-top-left-radius: 60%; ">
						<span class=" text-danger"><?php echo e($dev->proyect->fecha_limite); ?></span>
					</li>
					<li class="list-group-item bg-light border-0 text-center" style=";">
						<?php echo $__env->make('dev.trabajado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					</li>
					<li class="list-group-item bg-light border-0 text-center" style="border-bottom-right-radius: 60%;">
					</li>
				</a>
			</ul>
		</div>
	</div>
</div>