<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-12 mt-5">
			<h1 class=" text-center">Tu perfil</h1><br>
			<h4>Tus datos:</h4><br>
		</div>
		<div class="col-sm-12 ml-4">
			<div class="row">
				<div class="col-sm-6">
					<p class="lead"> Nombre: <strong class="text-dark"><?php echo e(Auth::user()->name); ?></strong> </p>
				</div>
				<div class="col-sm-6">
					<p class="lead"> Email: <strong class="text-dark"><?php echo e(Auth::user()->email); ?></strong> </p>
				</div>
				<div class="col-sm-6">
					<p class="lead"> Skype: <strong class="text-dark"><?php echo e(Auth::user()->cuentaSkype); ?></strong></p>
				</div>
				<div class="col-sm-6">
					<p class="lead"> Contacto: <strong class="text-dark"><?php echo e(Auth::user()->contacto); ?></strong></p>
				</div>
				<div class="col-sm-6">
					<p class="lead"> Estado: <strong class="text-<?php echo e(Auth::user()->getRoleColor()); ?>">Desarrollador</strong></p>
				</div>
				<div class="col-sm-6">
					<a href="<?php echo e(route('user.editar')); ?>" class="btn btn-outline-success btn-lg">Editar Datos</a>
				</div>
			</div>
		</div>
		<div class="col-sm-12">
			<hr><br>
			<h4>Tus interacciones con el mundo!</h4> <br>
			<div class="mb-3">
				<h5 class="text-center">Proyectos activos: <span class="text-info"><?php echo e(Auth::user()->devs->count()); ?></span></h5>
				<h5 class="text-center">Comentarios activos: <span class="text-info"><?php echo e(Auth::user()->comments->count()); ?></span></h5>
			</div>
			<br>
			<hr>
		</div>
		<div class="col-sm-12 my-3">
			<?php echo $__env->make('notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<br><br>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>