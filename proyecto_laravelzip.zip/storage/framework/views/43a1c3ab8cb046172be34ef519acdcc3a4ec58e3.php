<?php echo e(csrf_field()); ?>

<div class=" form-row ">
    <div class="col-sm-6 mx-auto"> 
        <label for="name" class="">Nombre</label>
        <input id="name" type="name" class="form-control <?php if( $errors->has('name')): ?> is-invalid <?php endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
        <?php if( $errors->has('name') ): ?>
        <div class="invalid-feedback">
            <strong> <?php echo e($errors->first('name')); ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class=" form-row ">
    <div class="col-sm-6 mx-auto"> 
        <label for="email" class="">Correo Electronico</label>
        <input id="email" type="email" class="form-control <?php if( $errors->has('email')): ?> is-invalid <?php endif; ?>" name="email" value="<?php echo e(old('email')); ?>"  required>
        <?php if( $errors->has('email') ): ?>
        <div class="invalid-feedback">
            <strong> <?php echo e($errors->first('email')); ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class=" form-row ">
    <div class="col-sm-6 mx-auto"> 
        <label for="NIF" class="">NIF</label>
        <input id="NIF" type="NIF" class="form-control <?php if( $errors->has('NIF')): ?> is-invalid <?php endif; ?>" name="NIF" value="<?php echo e(old('NIF')); ?>"  required>
        <?php if( $errors->has('NIF') ): ?>
        <div class="invalid-feedback">
            <strong> <?php echo e($errors->first('NIF')); ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class=" form-row ">
    <div class="col-sm-6 mx-auto"> 
        <label for="contacto" class="">Contacto</label>
        <input id="contacto" type="contacto" class="form-control <?php if( $errors->has('contacto')): ?> is-invalid <?php endif; ?>" name="contacto" value="<?php echo e(old('contacto')); ?>"  required>
        <?php if( $errors->has('contacto') ): ?>
        <div class="invalid-feedback">
            <strong> <?php echo e($errors->first('contacto')); ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class=" form-row ">
    <div class="col-sm-6 mx-auto"> 
        <label for="cuentaSkype" class="">Cuenta de Skype</label>
        <input id="cuentaSkype" type="cuentaSkype" class="form-control <?php if( $errors->has('cuentaSkype')): ?> is-invalid <?php endif; ?>" name="cuentaSkype" value="<?php echo e(old('cuentaSkype')); ?>"  required>
        <?php if( $errors->has('cuentaSkype') ): ?>
        <div class="invalid-feedback">
            <strong> <?php echo e($errors->first('cuentaSkype')); ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>
