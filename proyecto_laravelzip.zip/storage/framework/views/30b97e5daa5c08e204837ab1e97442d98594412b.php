<div class="container">
	<div class="row">
		<div class="col-sm-12 text-center text-dark my-3">
			<h3 class="text-info"> <?php echo e($proyecto->nombre); ?> </h3>
		</div>
		<div class="col-sm-6 text-center my-3">
			<h6>Creado por: <?php if(Auth::user()->isAdmin() ): ?> <a href="<?php echo e(route('user', $proyecto->user->id)); ?>" class="btn btn-primary btn-sm"> <?php echo e($proyecto->user->name); ?></a> 
				<?php else: ?> <span class="text-<?php echo e($proyecto->user->getRoleColor()); ?>"><?php echo e($proyecto->user->name); ?></span>
				<?php endif; ?> <?php echo e($proyecto->forHumansCreado()); ?>.</h6>
			</div>
			<div class="col-sm-6 text-center my-3">
				<strong>Id: <span class="badge badge-info"><?php echo e($proyecto->id); ?></span></strong>
			</div>
			<div class="col-sm-6 text-center my-2 align-self-center">
				<p>Limite: <strong><?php echo e($proyecto->fecha_limite); ?></strong></p>
			</div>
			<?php if( $proyecto->isEditado() and !$proyecto->isTerminado() ): ?>
			<div class="col-sm-6 text-center-my-2">	
				<p>Ultima vez que fue modificado: <strong><?php echo e($proyecto->forHumansEditado()); ?></strong></p>
			</div>
			<?php endif; ?>
			<div class="col-sm-6 text-center my-2 ">
				<?php if( $proyecto->isTerminado() ): ?>
				<?php if(Auth::user()->isAdmin()): ?>
				<a href="<?php echo e(route('proyecto.terminate', $proyecto->id)); ?>" class="btn btn-success">Poner proyecto en desarrollo.</a>
				<?php endif; ?>
				<h6><span class="text-success">Terminado</span> <?php echo e($proyecto->forHumansEditado()); ?></h6>
				<?php else: ?>	
				<?php if( Auth::user()->isAdmin()): ?>
				<div class="btn-group" role="group">
					<a class="btn btn-outline-secondary" href="<?php echo e(route('proyecto.reasignar', $proyecto->id)); ?>">Editar</a>
					<a class="btn btn-danger" href="<?php echo e(route('proyecto.eliminar', $proyecto->id)); ?>">Eliminar</a>
					<a class="btn btn-success" href="<?php echo e(route('proyecto.terminate', $proyecto->id)); ?>" >Terminar</a>
				</div>
				<?php endif; ?>
				<?php endif; ?>
			</div>
			<?php if( $proyecto->isTerminado() ): ?>
			<div class="col-sm-12 text-center alert alert-success">
				<h3 class="alert-heading">Este proyecto ya ha sido terminado!</h3>
			</div>
			<?php endif; ?>
			<?php if(Auth::user()->isDeveloper() and $proyecto->actualDev() ): ?>
			<div class="col-sm-12 my-3 p-2">
				<div class="mx-auto w-50">
					<h4 class="text-info text-center"> Trabajado </h4>
					<?php echo $__env->make('dev.trabajado', ['dev' => $proyecto->actualDev()] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<?php endif; ?>
			<?php $__empty_1 = true; $__currentLoopData = $proyecto->devs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<?php if( $loop->first): ?>
			<div class="col-sm-12 text-center my-2">
				<h4>Desarrolladores en este proyecto:</h4>
			</div>
			<div class="col-sm-12">
				<div class="row">
					<?php endif; ?>
					<?php if( Auth::user()->isAdmin() ): ?>
					<div class="col-sm-6">
						<div class="card-body border m-2 p-3">
							<h5 class="card-title text-center"><a class="text-dark" style="text-decoration: none;" data-toggle="collapse" href="#card<?php echo e($loop->index); ?>" role="button" aria-expanded="false" aria-controls="card<?php echo e($loop->index); ?>"><span class=" text-dark">
								<?php echo e($dev->user->name); ?>

							</span></a> </h5>
							<div class="collapse" id="card<?php echo e($loop->index); ?>">
								<a href="<?php echo e(route('user' , $dev->user->id)); ?>" style="text-decoration: none; display: block;">
									<p class="text-dark text-center">Trabajado<br> <?php echo $__env->make('dev.trabajado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></p>
								</a>
							</div>
						</div>
					</div>
					<?php else: ?>
					<div class="col-sm-4">
						<div class=" rounded border p-3 m-2 ">
							<h6 class="text-dark text-center"> <?php echo e($dev->user->name); ?></h6>
						</div>
					</div>
					<?php endif; ?>
					<?php if( $loop->last): ?>
				</div>
			</div>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<p>No hay desarrolladores asignados a este proyecto. <a href="/proyecto/reasignar/<?php echo e($proyecto->id); ?>">Asignar ahora.</a></p>
			<?php endif; ?>
			<?php if( Auth::user()->isAdmin() and $proyecto->isTerminado() ): ?>
			<div class="col-sm-12">
				<form action="/proyecto/delete/<?php echo e($proyecto->id); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="mx-5 alert alert-danger">
						<h3 class="alert-heading text-center">Eliminar Permanentemente el Proyecto.</h3>
						<hr>
						<div class="input-group p-3 rounded my-2 mx-5">
							<div class="input-group-prepend">
								<div class="input-group-text">
									<input name="aceptar" type="checkbox" required value="true">
									<span class="input-group-text" style="font-size: 18px;">Acepto borrar este proyecto y todos los datos relacionados con este.</span>
								</div>
							</div>
							<div class="input-group-append ml-5">
								<button class="btn btn-outline-danger h-100" type="submit">Borrar.</button>
							</div>
						</div>
					</div>
				</form>
			</div>
			<?php endif; ?>
			<div class="col-sm-12 text-center my-3">
				<a target="_blank" class="btn btn-outline-info btn-lg" href="<?php echo e(route('dev.proyecto', $proyecto->id)); ?>">Pagina de desarrollo de este proyecto.</a>
			</div>
			<div class="col-sm-12">
				<?php 
				switch($proyecto->proyect_type){
					case 0:
					 ?>
					<div class="col-sm-12 center-text">
						<h3>Dossier.</h3>
						Detalles del proyecto:
					</div>
					<?php echo $__env->make('proyecto.proyectoDossier', ['proyecto' => $proyecto->encontrar()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php 
					break;
					case 1:
					 ?>
					<div class="col-sm-12 center-text">
						<h3>Administracion De Redes Sociales</h3>
						Detalles del proyecto:
					</div>
					<?php echo $__env->make('proyecto.proyectoAdmSN', ['proyecto' => $proyecto->encontrar()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php 
					break;
					case 2:
					 ?> 
					<div class="row my-2">
						<div class="col-sm-12">
							<h3 class="text-dark text-center">Descripcion</h3> 
						</div>
						<div class="col-sm-8 mx-auto">
							<div class="p-2 m-2 border rounded border-secondary bg-light">
								<?php echo e($proyecto->encontrar()->descripcion); ?>

							</div>
						</div>
					</div>
					<?php 
					break;
					default:
					 ?>
					Error al guardar el proyecto
					<?php 
					break;
				}
				 ?>
			</div>
			<div class="col-sm-12 my-2">
				<?php if( Auth::user()->isAdmin() and ! $proyecto->isCustom() ): ?>
				<p><a class="btn btn-outline-secondary" href=" <?php echo e(route('user', $proyecto->encontrar()->user->id )); ?>"><?php echo e($proyecto->encontrar()->user->name); ?></a></p>
				<?php endif; ?>
			</div>
		</div>
	</div>