<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row my-2">
      <div class="col-sm-12">
        <h3 class="text-center text-primary">Bienvenido al Registro</h3>
    </div>
    <div class="col-sm-12">
        <form  method="POST" action="<?php echo e(route('register')); ?>" class="">
            <div class="">
                <?php echo $__env->make('user.crear', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class=" form-row ">
                    <div class="col-sm-6 mx-auto"> 
                        <label for="password" class="">Contraseña</label>
                        <input id="password" type="password" class="form-control <?php if( $errors->has('password')): ?> is-invalid <?php endif; ?>" name="password" required>
                        <?php if( $errors->has('password') ): ?>
                        <div class="invalid-feedback">
                            <strong> <?php echo e($errors->first('password')); ?></strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div> 

                <div class=" form-row ">
                    <div class="col-sm-6 mx-auto"> 
                        <label for="password-confirm" class="">Confirma la Contraseña</label>
                        <input id="password-confirm" type="password" class="form-control <?php if( $errors->has('password_confirmation')): ?> is-invalid <?php endif; ?>" name="password_confirmation" required>
                    </div>
                </div>
                
                <div class="form-row mt-3">
                    <div class="col-sm-6 mx-auto">
                        <button type="submit" class="btn btn-primary">
                            Registrarse
                        </button>
                    </div>
                </div>

            </div>
        </form>
    </div>
</div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>