<?php $__env->startSection('content'); ?>
<div class="container mt-3">
	<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php if($loop->first): ?>
	<div class="row">
		<div class="col-sm-6">
			<h3 class="text-dark text-center">Usuarios</h3>
		</div>
		<div class="col-sm-6">
			<?php echo $__env->make('searchBar', ['action' =>route('admin.buscar.user')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
	<hr class="mt-3 mb-3">
	<div class="row">
		<?php endif; ?>
		<?php echo $__env->make('user.userMIN', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php if($loop->last): ?>
	</div>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<div class="row">
		<div class="col-sm-12 alert alert-warning">
			<h4 class="alert-heading">Parece que no hay ningun usuario registrado!</h4>
			<hr>
			<a href="<?php echo e(route('user.crear.admin')); ?>" class="btn btn-primary">Crear un nuevo usuario ahora.</a>
		</div>
	</div>
	<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>