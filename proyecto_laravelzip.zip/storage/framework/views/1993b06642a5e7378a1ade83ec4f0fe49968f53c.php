<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-12 mt-5">
			<h1 class=" text-center">Tu perfil</h1><br>
			<h4>Tus datos:</h4><br>
			<div class="ml-4">
				<p class="lead"> Nombre: <strong class="text-dark"><?php echo e(Auth::user()->name); ?></strong> </p>
				<p class="lead"> Email: <strong class="text-dark"><?php echo e(Auth::user()->email); ?></strong> </p><br>
				<div class="text-right">
					<a href="<?php echo e(route('user.editar')); ?>" class="text-right btn btn-outline-success btn-lg">Editar Datos</a>
				</div>
				<p class="lead"></p>
			</div>
			<hr><br>
			<h4>Tus interacciones con el mundo!</h4> <br>
			<div class="mb-3">
				<h5 class="text-center">Proyectos activos: <span class="text-info"><?php echo e(Auth::user()->proyects->count()); ?></span></h5>
				<h5 class="text-center">Comentarios activos: <span class="text-info"><?php echo e(Auth::user()->comments->count()); ?></span></h5>
			</div>
			<br>
			<hr>
			<?php echo $__env->make('notifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<br><br>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>