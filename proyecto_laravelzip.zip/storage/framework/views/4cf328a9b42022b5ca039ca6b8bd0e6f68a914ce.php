<div>
	<form action="">
		<input type="text" placeholder="Buscar nombre.." name="query">
		<button type="submit">Buscar</button>
	</form>
</div>